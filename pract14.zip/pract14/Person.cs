﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pract14
{
    class Person
    {
        private string surname;
        private string name;
        private string otch;
        private int age;
        private double ves;
        public Person(string surname, string name, string otch)
        {
            this.surname = surname;
            this.name = name;
            this.otch = otch;
        }
        public Person(string surname, string name, string otch, int age, double ves)
        {
            this.surname = surname;
            this.name = name;
            this.otch = otch;
            this.age = age;
            this.ves = ves;
        }
        public Person(int age, double ves)
        {
           
            this.age = age;
            this.ves = ves;
        }
        public void Set_surname(string surname)
        {
            this.surname = surname;
        }
        public string Get_surname()
        {
            return this.surname;
        }
        public void Set_name(string name)
        {
            this.name = name;
        }
        public string Get_name()
        {
            return this.name;
        }
        public void Set_otch(string otch)
        {
            this.otch = otch;
        }
        public string Get_otch()
        {
            return this.otch;
        }
        public void Set_age(int age)
        {
            this.age = age;
        }
        public int Get_age()
        {
            return this.age;
        }
        public void Set_ves(double ves)
        {
            this.ves = ves;
        }
        public double Get_ves()
        {
            return this.ves;
        }
    }
}

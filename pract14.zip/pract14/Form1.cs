﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pract14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(numericUpDown1.Value);
            Stack<int> num = new Stack<int>();
            listBox1.Items.Add($"Размерность стека={n}");
            listBox1.Items.Add($"Верхний элемент стека={n}");
            for (int i = 1; i <= n; i++)
            {
                num.Push(i);
            }
            listBox1.Items.Add($"Размерность стека={num.Count}");
            listBox1.Items.Add($"Содержимое стека:{string.Join(" ", num)}");

            listBox1.Items.Add($"Новая размерность стека={num.Count}");

        }

        private void button2_Click(object sender, EventArgs e)
        {
      
            bool a = true;
            int l = 0, p = 0;
            StreamWriter z2 = File.CreateText("new.txt");
            Stack<char> stack = new Stack<char>();
            try
            {
                if (textBox1.Text != "")
                {
                    string s = textBox1.Text;
                    for (int i = 0; i < s.Length; i++)
                    {
                        stack.Push(s[i]);
                        char k = s[i];
                        if (char.IsDigit(s[i]))
                            a = false;
                        if (stack.Peek() == ')') p++;
                        if (stack.Peek() == '(') l++;
                    }
                    if (a == true && p == l)
                    {
                        listBox2.Items.Add("скобки сбалансированы");
                        listBox2.Items.Add(s);
                        z2.WriteLine(s);
                        z2.Close();
                    }
                    else if (p > l)
                    {
                        listBox2.Items.Add($"возможно лишняя ) скобка на позиции: {textBox1.Text.IndexOf('(')}");
                        StreamWriter z22 = new StreamWriter("new1.txt");
                        z22.WriteLine(')' + textBox1.Text);
                        z22.Close();
                    }
                    else if (p < l)
                    {
                        listBox2.Items.Add($"возможно лишняя ( скобка на позиции: {textBox1.Text.IndexOf(')')}");
                        StreamWriter z23 = new StreamWriter("new1.txt");
                        z23.WriteLine(textBox1.Text + ')');
                        z23.Close();
                    }
                    else MessageBox.Show("Вы не ввели выражение");
                }

            }
            catch (FormatException) { MessageBox.Show("что-то пошло не так"); }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Queue<int> num = new Queue<int>();
            num.Clear();
            int n = Convert.ToInt32(numericUpDown2.Value);
            for (int i = 1; i <= n; i++)
            {
                num.Enqueue(i);
            }
            if (num.Count > 0)
            {
                listBox3.Items.Add($"n={numericUpDown2.Text}");
                listBox3.Items.Add($"Размерность очереди: {num.Count}");
                listBox3.Items.Add($"Верхний элемент сочереди:{string.Join(" ", num)}");
                num.Clear();
                listBox3.Items.Add($"Новая размерность очереди:{num.Count}");
            }
            else MessageBox.Show("Очередь пустая");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Queue<Person> people = new Queue<Person>();
            string file = "file.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден");
            }
            else
            {
                string[] stroki = File.ReadAllLines(file);

                Person peop = new Person("", "", "", 0, 0.0);

                foreach (string s in stroki)
                {
                    string[] peopl = s.Split(' ');
                    string surname = peopl[0];
                    peop.Set_surname(surname);
                    string name = peopl[1];
                    peop.Set_name(name);
                    string otch = peopl[2];
                    peop.Set_otch(otch);
                    int age = Convert.ToInt32(peopl[3]);
                    peop.Set_age(age);
                    double ves = Convert.ToDouble(peopl[4]);
                    peop.Set_ves(ves);
                    listBox4.Items.Add($"{peop.Get_surname()} {peop.Get_name()} {peop.Get_otch()}, Возраст: {peop.Get_age()} лет, Вес:{peop.Get_ves()} кг");
                    people.Enqueue(new Person(surname, name, otch, age, ves));
                }
                var yung = from p in people
                           where Convert.ToInt32(p.Get_age()) < 40
                           select p;

                foreach (var a in yung)
                {
                    listBox5.Items.Add($"{a.Get_surname()} {a.Get_name()} {a.Get_otch()}, Возраст: {a.Get_age()} лет, Вес: {a.Get_ves()} кг");
                }
            }

        }
        private void button6_Click(object sender, EventArgs e)
        {
            Queue<Person> peoples = new Queue<Person>();
            string file1 = "file1.txt";
            string file2 = "file2.txt";
            if (!File.Exists(file1) && !File.Exists(file2))
            {
                MessageBox.Show("файл не найден");
            }
            else
            {
                string[] st1 = File.ReadAllLines(file1);
                Person peo = new Person("", "", "");
                foreach (string s1 in st1)
                {
                    string[] p = s1.Split(' ');
                    string name = p[0];
                    peo.Set_name(name);
                    string surname = p[1];
                    peo.Set_surname(surname);
                    string otch = p[2];
                    peo.Set_otch(otch);
                    listBox9.Items.Add($"{peo.Get_name()} {peo.Get_surname()} {peo.Get_otch()}");
                    peoples.Enqueue(new Person(name, surname, otch));
                    listBox8.Items.Add($"{peo.Get_name()} {peo.Get_surname()} {peo.Get_otch()}");
                    listBox8.Sorted = (true);

                }
                string[] st2 = File.ReadAllLines(file2);
                Person peo2 = new Person(0, 0.0);
                foreach (string s2 in st2)
                {
                    string[] p3 = s2.Split(' ');
                    int age = Convert.ToInt32(p3[0]);
                    peo2.Set_age(age);
                    double ves = Convert.ToDouble(p3[1]);
                    peo2.Set_ves(ves);
                    listBox9.Items.Add($"Возраст: {peo2.Get_age()} Вес: {peo2.Get_ves()}");
                    peoples.Enqueue(new Person(age, ves));
                    listBox8.Items.Add($"{peo2.Get_age()} {peo2.Get_ves()}");
                    listBox9.Sorted = (true);
                    peoples.Enqueue(new Person(age, ves));
                }

            }
        }
    }
    }
    
    
    

